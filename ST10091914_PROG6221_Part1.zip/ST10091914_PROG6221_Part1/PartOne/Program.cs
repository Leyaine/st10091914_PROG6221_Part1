﻿using PartOne.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace PartOne
{
    internal class Program
    {
        static int tableWidth = 73;
        static void Main(string[] args)
        {
            Console.Write("Recipe App\n");
            bool CloseSystem = false;
            while (CloseSystem == false)
            {
                Console.Write("Enter recipe name:");
                string Rname = Console.ReadLine();
                Console.Write("Number of ingredient:");
                string ni = Console.ReadLine();
                var isNumericNi = int.TryParse(ni, out _);
                if (!isNumericNi)
                {
                    Console.Write("Number of ingredient (must be a number):");
                    ni = Console.ReadLine();
                    var _isNumericNi = int.TryParse(ni, out _);
                    if (!_isNumericNi)
                    {
                        Console.Write("Restart\n");
                        continue;
                    }
                }
                Console.Write("Number of steps:");
                string ns = Console.ReadLine();
                var isNumericNs = int.TryParse(ns, out _);
                if (!isNumericNs)
                {
                    Console.Write("Number of steps (must be a number):");
                    ns = Console.ReadLine();
                    var _isNumericNs = int.TryParse(ns, out _);
                    if (!_isNumericNs)
                    {
                        Console.Write("Restart\n");
                        continue;
                    }
                }
                Console.Write("Scale factor:");
                string scale = Console.ReadLine();
                var isNumericS = int.TryParse(scale, out _);
                if (!isNumericS)
                {
                    Console.Write("Scale (must be a number):");
                    scale = Console.ReadLine();
                    var _isNumericS = int.TryParse(scale, out _);
                    if (!_isNumericS)
                    {
                        Console.Write("Restart\n");
                        continue;
                    }
                }
                Recipe _Recipe = new Recipe(Rname, Convert.ToInt32(ni), Convert.ToInt32(ns), Convert.ToDouble(scale));
                for(int i=0;  i < Convert.ToInt32(ni); i++) // collect recipe ingredients
                {
                    Console.WriteLine("Ingredient (" + (i + 1) + ")");
                    Console.Write("Enter name:");
                    string  name = Console.ReadLine();
                    Console.Write("Unit of measure:");
                    string uom = Console.ReadLine();
                    Console.Write("Quantity:");
                    string q = Console.ReadLine();
                    var isNumericQ = int.TryParse(q, out _);
                    if (!isNumericQ)
                    {
                        Console.Write("Quantity (must be a number):");
                        q = Console.ReadLine();
                        var _isNumericQ = int.TryParse(q, out _);
                        if (!_isNumericQ)
                        {
                            Console.Write("Restart\n");
                            continue;
                        }
                    }
                    _Recipe.Ingredients[i] = new Ingredient(name, uom, Convert.ToInt32(q));
                    Console.WriteLine(_Recipe.Ingredients.Count());
                }
                for (int i = 0; i < Convert.ToInt32(ns); i++) // collect recipe ingredients
                {

                    Console.Write("Step ("+(i+1)+") description:");
                    string desc = Console.ReadLine();
                    _Recipe.Steps[i] = new Step(desc);
                }
                DisplayRecipe(_Recipe);
                for(int i=0; i < 2; i++) // allow user to reset and print again
                {
                    Console.Write("Press x (close the system), r (reset quantity and print again) and ANY KEY (enter new recipe record):");
                    string flag = Console.ReadLine();
                    if (flag == "x" || flag == "X")
                    {
                        CloseSystem = true;
                        i = 4;
                        continue;
                    }else if(flag == "r" || flag == "R")
                    {
                        _Recipe.Scaled = 1;
                        DisplayRecipe(_Recipe);
                    }
                    else
                    {
                        i = 4; continue;
                    }
                }
                
            }
        }

       static void DisplayRecipe(Recipe recipe)
        {
            PrintLine();
            Console.WriteLine("Recipe:" + recipe.Name);
            PrintLine();
            Console.WriteLine("Ingredients:");
            PrintRow("","Name", "Unit of measure", "Quantity");
            PrintLine();
            int index=1;
            foreach(Ingredient ingredient in recipe.Ingredients)
            {

                PrintRow((index++).ToString(),ingredient.Name, ingredient.Unit_Of_Measure,(ingredient.Quantity*recipe.Scaled).ToString());
            }
            PrintLine();
            Console.WriteLine("Steps:");
            PrintRow("","Description");
            PrintLine();
            index = 1;
            foreach (Step step in recipe.Steps)
            {
                PrintRow((index++).ToString(), step.Description);
            }
            PrintLine();
        }
        static void PrintLine()
        {
            Console.WriteLine(new string('-', tableWidth));
        }
        static void PrintRow(params string[] columns) // print in table format 
        {
            int width = (tableWidth - columns.Length) / columns.Length;
            string row = "|";

            foreach (string column in columns)
            {
                row += Padding(column, width) + "|";
            }

            Console.WriteLine(row);
        }

        static string Padding(string text, int width) // align center values
        {
            text = text.Length > width ? text.Substring(0, width - 3) + "..." : text;

            if (string.IsNullOrEmpty(text))
            {
                return new string(' ', width);
            }
            else
            {
                return text.PadRight(width - (width - text.Length) / 2).PadLeft(width);
            }
        }
    }
}
