﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartOne.Models
{
    internal class Ingredient
    {
        public string Name { get; set; }
        public string Unit_Of_Measure { get; set; }
        public int Quantity { get; set; }
        public Ingredient(string name, string uom,int quantity) {
          Name = name;
          Unit_Of_Measure = uom;
          Quantity = quantity;
        }
    }
}
