﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartOne.Models
{
    internal class Recipe
    {
        public string Name { get; set; }
        public int Number_Ingredient {get;set;}
        public int Number_Steps { get; set; }
        public double Scaled { get; set; }
        public Step[] Steps { get; set; } // hold steps
        public Ingredient[] Ingredients { get; set; } // hold ingredients
         
        public Recipe(string name, int ni,int ns,double scaled) { 
            Name = name;    
            Number_Ingredient = ni;
            Number_Steps = ns;
            Scaled = scaled;
            Steps = new Step[ns]; //initialize steps array
            Ingredients = new Ingredient[ni];  //initialize ingredients array
        }
    }
}
