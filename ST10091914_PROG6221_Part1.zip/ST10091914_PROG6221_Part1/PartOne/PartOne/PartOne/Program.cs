﻿using PartOne.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace PartOne
{
    internal class Program
    {
        static int tableWidth = 73;
        static void Main(string[] args)
        {
            Console.Write("Recipe App\n");
            bool CloseSystem = false;
            while (CloseSystem == false)
            {
                Console.Write("Enter recipe name:");
                string Rname = Console.ReadLine();
                Console.Write("Number of ingredient:");
                string ni = Console.ReadLine();
                var isNumericNi = int.TryParse(ni, out _);
                if (!isNumericNi)
                {
                    Console.Write("Number of ingredient (must be a number):");
                    ni = Console.ReadLine();
                    var _isNumericNi = int.TryParse(ni, out _);
                    if (!_isNumericNi)
                    {
                        Console.Write("Restart\n");
                        continue;
                    }
                }
               